$(window).ready(function () {
  $(".btn").css("background-color", "transparent");
});