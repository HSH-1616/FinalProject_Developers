package com.dev.ac.service;

import java.util.List;

import com.dev.ac.dto.Accommodation;

public interface AcService {
	
	List<Accommodation> acListAll();
}
