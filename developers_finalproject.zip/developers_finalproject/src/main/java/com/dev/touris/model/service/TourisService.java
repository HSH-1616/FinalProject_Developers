package com.dev.touris.model.service;

import java.util.List;

import com.dev.touris.model.vo.Touris;

public interface TourisService {

}
