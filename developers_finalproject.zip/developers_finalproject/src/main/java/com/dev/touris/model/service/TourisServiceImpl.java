package com.dev.touris.model.service;



import org.springframework.stereotype.Service;


@Service
public class TourisServiceImpl implements TourisService {


}
