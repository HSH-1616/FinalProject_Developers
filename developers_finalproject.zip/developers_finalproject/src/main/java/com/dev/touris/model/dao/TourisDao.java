package com.dev.touris.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

import com.dev.touris.model.vo.Touris;

public interface TourisDao {

}
