package com.dev.touris.common.file;

public class ExcelFileType {

}
