package com.dev.touris.model.dao;

import java.util.List;


public class TourisDaoImpl implements TourisDao {

}
