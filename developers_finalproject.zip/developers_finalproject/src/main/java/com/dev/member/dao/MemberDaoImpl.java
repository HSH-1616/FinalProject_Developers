package com.dev.member.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.dev.member.model.dto.Member;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Override
	public Member selectByEmail(SqlSession session, String email) {
		System.out.println(email);
		email="ert246@naver.com";
		System.out.println("뭐지? : "+session.selectOne("member.selectByEmail", email));
		return session.selectOne("member.selectByEmail", email);
	}

	@Override
	public void insertMember(SqlSession session, Member m) {
			session.insert("member.insertMember", m);
		
	}
	
	

}
