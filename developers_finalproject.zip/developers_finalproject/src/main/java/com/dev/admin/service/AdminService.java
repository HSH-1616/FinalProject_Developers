package com.dev.admin.service;

import java.util.Map;

import com.dev.admin.model.dto.Admin;

public interface AdminService {
	
	Admin adminLogin(Map param);

}
