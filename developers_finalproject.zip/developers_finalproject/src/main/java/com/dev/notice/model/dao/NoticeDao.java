package com.dev.notice.model.dao;

public interface NoticeDao {

}
