package com.dev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevelopersFinalprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
